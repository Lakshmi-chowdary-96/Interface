class BinaryToDecimal{
	public static void main(String args[]){
		System.out.println("Decimal representation of 0110");
		System.out.println(Integer.toDecimalString(110));
		System.out.println("Binary representation of 11110");
		System.out.println(Integer.toDecimalString(11110));
	}
}