class Numbers{
	public static void main(String args[]){
	int i,j;
			for(i=1;i<=10;i++){
			int n=i;
			for(j=1;j<=10;j++){
			 
				System.out.print(n+"\t");
				n+=10;		
			}
		}	System.out.println();
	}
}
