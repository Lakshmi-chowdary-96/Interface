public class Swaping{
public static void main(String args[]){
	int n1=7;
	int n2=8;
	System.out.println(n1+" "+n2);
	int temp=n1;
	n1=n2;
	n2=temp;
	System.out.println(n1+" "+n2);
}
}
