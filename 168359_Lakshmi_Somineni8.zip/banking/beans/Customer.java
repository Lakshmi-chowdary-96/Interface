package com.cg.banking.beans;

public class Customer {
	private int customerId,adharNo,dateOfBirth;
	private String firstName,lastName,pancardNo,emailId;
public Customer() {}
public Customer(int customerId, int adharNo, int dateOfBirth, String firstName, String lastName, String pancardNo,
		String emailId) {
	super();
	this.customerId = customerId;
	this.adharNo = adharNo;
	this.dateOfBirth = dateOfBirth;
	this.firstName = firstName;
	this.lastName = lastName;
	this.pancardNo = pancardNo;
	this.emailId = emailId;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public int getAdharNo() {
	return adharNo;
}
public void setAdharNo(int adharNo) {
	this.adharNo = adharNo;
}
public int getDateOfBirth() {
	return dateOfBirth;
}
public void setDateOfBirth(int dateOfBirth) {
	this.dateOfBirth = dateOfBirth;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getPancardNo() {
	return pancardNo;
}
public void setPancardNo(String pancardNo) {
	this.pancardNo = pancardNo;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
	

}
