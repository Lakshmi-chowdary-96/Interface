package com.cg.payroll.client;

public class MainClass {
	public static void main(String args[]) {
		
	}
}


